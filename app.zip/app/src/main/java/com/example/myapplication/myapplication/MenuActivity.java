package com.example.myapplication.myapplication;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Nagesh on 17/06/26.
 */

public class MenuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.option_menu);
        getActionBar();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        /**
         * Inflater is use to add the resource file "menu" to the action bar
         */
        MenuInflater Menu=getMenuInflater();
        Menu.inflate(R.menu.menu,menu);

        return true;
    }
    /**
     * then we have to see which option is selected in the menu
     *onOptionsItemSelected
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
         int opmenu=item.getItemId();
        switch (item.getItemId()) {
            case R.id.Red:
                TextView txt=(TextView)findViewById(R.id.textView);
                txt.setText("I love my country");
                txt.setTextColor (Color.parseColor("#f44336"));
                Toast.makeText(getApplicationContext(), "values saved", Toast.LENGTH_LONG).show();
                break;
            case R.id.Blue:
                TextView txt2=(TextView)findViewById(R.id.textView2);
                txt2.setText("Barath");
                txt2.setTextColor (Color.parseColor("#FF4B4EF4"));
                Toast.makeText(getApplicationContext(), "Refresh the values", Toast.LENGTH_LONG).show();
                break;
            case R.id.Green:
                TextView txt3=(TextView)findViewById(R.id.textView3);
                txt3.setText("India");
                txt3.setTextColor (Color.parseColor("#FF40FB11"));
                Toast.makeText(getApplicationContext(), "Editing the values", Toast.LENGTH_LONG).show();
                break;
        }



        return true;
    }
}
