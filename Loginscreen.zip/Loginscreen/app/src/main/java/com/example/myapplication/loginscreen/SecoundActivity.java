package com.example.myapplication.loginscreen;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;


/**
 * Created by Nagesh on 17/06/09.
 */

public class SecoundActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.succesful);
       TextView textView=(TextView)findViewById(R.id.editText);
        textView.setText("user:"+textView);
    }
}
